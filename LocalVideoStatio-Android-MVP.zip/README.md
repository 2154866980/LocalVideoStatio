# LocalVideoStatio
本地视频站 Android MVP。

当前包含：本地视频多选导入、搜索、收藏、Media3 播放器、深色 UI、GitHub Actions APK 构建。

后续可继续加入：Room 持久化、播放进度/历史、作者、标签、评分、推荐、缩略图、文件夹扫描等。

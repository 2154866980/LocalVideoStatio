package com.localvideostatio.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

data class Video(val uri: Uri, val title: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    var videos by remember { mutableStateOf(listOf<Video>()) }
    var selected by remember { mutableStateOf<Video?>(null) }
    var query by remember { mutableStateOf("") }
    var favorites by remember { mutableStateOf(setOf<Uri>()) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        videos = (videos + uris.map {
            Video(it, it.lastPathSegment?.substringAfterLast('/') ?: "本地视频")
        }).distinctBy { it.uri }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFFFF6699),
        background = Color(0xFF0B0B0F),
        surface = Color(0xFF17171E)
    )) {
        if (selected != null) {
            Player(selected!!, { selected = null })
        } else {
            Scaffold(
                topBar = {
                    Column(Modifier.fillMaxWidth().background(Color(0xFF101015)).padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("本地视频站", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.weight(1f))
                            Button(onClick = { picker.launch(arrayOf("video/*")) }) { Text("导入视频") }
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = query, onValueChange = { query = it },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            placeholder = { Text("搜索视频…") }
                        )
                    }
                }
            ) { pad ->
                val list = videos.filter { it.title.contains(query, true) }
                if (list.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
                        Text("还没有视频，点击「导入视频」")
                    }
                } else {
                    LazyColumn(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
                        items(list) { video ->
                            Card(
                                Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { selected = video },
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF17171E))
                            ) {
                                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(video.title, fontWeight = FontWeight.SemiBold)
                                        Text("本地视频")
                                    }
                                    TextButton(onClick = {
                                        favorites = if (video.uri in favorites) favorites - video.uri else favorites + video.uri
                                    }) { Text(if (video.uri in favorites) "♥" else "♡") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Player(video: Video, onBack: () -> Unit) {
    val context = LocalContext.current
    val player = remember(video.uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(video.uri))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        TextButton(onClick = onBack) { Text("‹ 返回") }
        AndroidView(
            factory = { PlayerView(it).apply { this.player = player } },
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
        )
        Text(video.title, Modifier.padding(16.dp), style = MaterialTheme.typography.titleLarge)
    }
}
